from flask import Blueprint

blueprint = Blueprint('donor_blueprint', __name__, url_prefix='/donor')

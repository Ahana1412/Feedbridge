from flask import Blueprint

blueprint = Blueprint('food_bank_blueprint', __name__, url_prefix='/food_bank')


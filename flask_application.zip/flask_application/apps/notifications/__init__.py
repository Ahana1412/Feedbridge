from flask import Blueprint

notifications_blueprint = Blueprint('notifications', __name__, url_prefix='/notifications')

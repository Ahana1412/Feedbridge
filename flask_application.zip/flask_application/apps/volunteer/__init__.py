from flask import Blueprint

blueprint = Blueprint('volunteer_blueprint', __name__, url_prefix='/volunteer')
